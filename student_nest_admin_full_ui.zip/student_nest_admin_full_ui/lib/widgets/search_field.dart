import 'package:flutter/material.dart';

class SearchField extends StatelessWidget {
  final String hint;
  final IconData icon;
  final double borderRadius;

  const SearchField({
    super.key,
    required this.hint,
    this.icon = Icons.search,
    this.borderRadius = 999,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return TextField(
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, size: 20),
        filled: true,
        fillColor: theme.cardColor,
        contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(borderRadius),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
