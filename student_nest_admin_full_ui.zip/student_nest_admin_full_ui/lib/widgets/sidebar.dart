import 'package:flutter/material.dart';

class Sidebar extends StatelessWidget {
  final bool isCollapsed;
  final VoidCallback onToggle;

  const Sidebar({
    super.key,
    required this.isCollapsed,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bool isDark = theme.brightness == Brightness.dark;

    return Container(
      width: isCollapsed ? 80 : 260,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isDark
              ? const [Color(0xFF020617), Color(0xFF020617)]
              : const [Color(0xFF1D4ED8), Color(0xFF1E40AF)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Header / Logo
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: onToggle,
                    icon: const Icon(Icons.menu, color: Colors.white),
                    tooltip: "Toggle sidebar",
                  ),
                  if (!isCollapsed) ...[
                    const SizedBox(width: 8),
                    const Text(
                      "Student Nest",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 8),
            // Navigation items
            Expanded(
              child: ListView(
                children: const [
                  _SidebarItem(
                    icon: Icons.dashboard_outlined,
                    label: "Dashboard",
                    routeName: "/dashboard",
                  ),
                  _SidebarItem(
                    icon: Icons.people_alt_outlined,
                    label: "Users Management",
                    routeName: "/users",
                  ),
                  _SidebarItem(
                    icon: Icons.verified_user_outlined,
                    label: "Landlords Verification",
                    routeName: "/landlords",
                  ),
                  _SidebarItem(
                    icon: Icons.apartment_outlined,
                    label: "Listings Moderation",
                    routeName: "/listings",
                  ),
                  _SidebarItem(
                    icon: Icons.report_gmailerrorred_outlined,
                    label: "Reports & Violations",
                    routeName: "/reports",
                  ),
                  _SidebarItem(
                    icon: Icons.home_work_outlined,
                    label: "Booked Apartments",
                    routeName: "/booked",
                  ),
                  _SidebarItem(
                    icon: Icons.history_toggle_off,
                    label: "Activity Logs",
                    routeName: "/activity",
                  ),
                  Divider(color: Colors.white24, height: 24),
                  _SidebarItem(
                    icon: Icons.settings_outlined,
                    label: "Settings",
                    routeName: "/settings",
                  ),
                ],
              ),
            ),
            // User footer
            if (!isCollapsed)
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: const [
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.white24,
                      child: Icon(Icons.person, color: Colors.white),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        "Admin",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _SidebarItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String routeName;

  const _SidebarItem({
    required this.icon,
    required this.label,
    required this.routeName,
  });

  @override
  Widget build(BuildContext context) {
    final bool isSelected =
        ModalRoute.of(context)?.settings.name == routeName;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          if (!isSelected) {
            Navigator.pushNamedAndRemoveUntil(
              context,
              routeName,
              (route) => false,
            );
          }
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: isSelected ? Colors.white.withOpacity(0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.white, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
