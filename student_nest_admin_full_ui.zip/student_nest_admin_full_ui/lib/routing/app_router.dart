import 'package:flutter/material.dart';

import '../screens/dashboard_screen.dart';
import '../screens/users_management_screen.dart';
import '../screens/landlords_verification_screen.dart';
import '../screens/listings_moderation_screen.dart';
import '../screens/reports_violations_screen.dart';
import '../screens/booked_apartments_screen.dart';
import '../screens/activity_logs_screen.dart';
import '../screens/settings_screen.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case "/dashboard":
        return MaterialPageRoute(builder: (_) => const DashboardScreen());
      case "/users":
        return MaterialPageRoute(builder: (_) => const UsersManagementScreen());
      case "/landlords":
        return MaterialPageRoute(builder: (_) => const LandlordsVerificationScreen());
      case "/listings":
        return MaterialPageRoute(builder: (_) => const ListingsModerationScreen());
      case "/reports":
        return MaterialPageRoute(builder: (_) => const ReportsViolationsScreen());
      case "/booked":
        return MaterialPageRoute(builder: (_) => const BookedApartmentsScreen());
      case "/activity":
        return MaterialPageRoute(builder: (_) => const ActivityLogsScreen());
      case "/settings":
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      default:
        return MaterialPageRoute(builder: (_) => const DashboardScreen());
    }
  }
}
