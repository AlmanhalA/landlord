import 'package:flutter/material.dart';

class AppTheme {
  static const Color primaryBlue = Color(0xFF2563EB);
  static const Color sidebarDark = Color(0xFF020617);
  static const Color sidebarLight = Color(0xFFE5ECFF);
  static const Color bgLight = Color(0xFFF5F7FB);
  static const Color bgDark = Color(0xFF020617);

  static final ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: bgLight,
    primaryColor: primaryBlue,
    colorScheme: ColorScheme.fromSeed(
      seedColor: primaryBlue,
      brightness: Brightness.light,
    ),
    cardColor: Colors.white,
    useMaterial3: true,
    fontFamily: "Roboto",
  );

  static final ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgDark,
    primaryColor: primaryBlue,
    colorScheme: ColorScheme.fromSeed(
      seedColor: primaryBlue,
      brightness: Brightness.dark,
    ),
    cardColor: const Color(0xFF0F172A),
    useMaterial3: true,
    fontFamily: "Roboto",
  );
}
