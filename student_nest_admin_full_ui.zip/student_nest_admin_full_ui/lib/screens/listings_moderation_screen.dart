import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stats_card.dart';
import '../widgets/data_table_box.dart';

class ListingsModerationScreen extends StatefulWidget {
  const ListingsModerationScreen({super.key});

  @override
  State<ListingsModerationScreen> createState() =>
      _ListingsModerationScreenState();
}

class _ListingsModerationScreenState extends State<ListingsModerationScreen> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 900;

    return Scaffold(
      drawer: isMobile
          ? Drawer(
        child: Sidebar(
          isCollapsed: false,
          onToggle: () {},
        ),
      )
          : null,
      body: Row(
        children: [
          if (!isMobile)
            Sidebar(
              isCollapsed: isCollapsed,
              onToggle: () {
                setState(() => isCollapsed = !isCollapsed);
              },
            ),
          Expanded(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Listings Moderation",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 24),

                      // KPI cards
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final isNarrow = constraints.maxWidth < 900;
                          final double cardWidth = isNarrow
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 48) / 4;
                          return Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Pending Listings",
                                  value: "21",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Approved",
                                  value: "650",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Rejected",
                                  value: "14",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Removed",
                                  value: "3",
                                ),
                              ),
                            ],
                          );
                        },
                      ),

                      const SizedBox(height: 24),

                      const DataTableBox(
                        title: "",
                        columns: [
                          "Title",
                          "Location",
                          "Price",
                          "Status",
                          "Action",
                        ],
                        rows: [
                          [
                            "1BHK Near Uni",
                            "Amman",
                            "\$250",
                            "Pending",
                            "Approve / Reject / Remove",
                          ],
                          [
                            "Shared Room",
                            "Amman",
                            "\$180",
                            "Active",
                            "Remove",
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
