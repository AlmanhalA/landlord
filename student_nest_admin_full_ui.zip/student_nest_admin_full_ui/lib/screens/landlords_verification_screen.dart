import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stats_card.dart';
import '../widgets/data_table_box.dart';

class LandlordsVerificationScreen extends StatefulWidget {
  const LandlordsVerificationScreen({super.key});

  @override
  State<LandlordsVerificationScreen> createState() =>
      _LandlordsVerificationScreenState();
}

class _LandlordsVerificationScreenState
    extends State<LandlordsVerificationScreen> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 900;

    return Scaffold(
      drawer: isMobile
          ? Drawer(
        child: Sidebar(
          isCollapsed: false,
          onToggle: () {},
        ),
      )
          : null,
      body: Row(
        children: [
          if (!isMobile)
            Sidebar(
              isCollapsed: isCollapsed,
              onToggle: () {
                setState(() => isCollapsed = !isCollapsed);
              },
            ),
          Expanded(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Landlords Verification",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Top KPI cards
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final isNarrow = constraints.maxWidth < 900;
                          final double cardWidth = isNarrow
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 32) / 3;
                          return Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Pending Reviews",
                                  value: "18",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Verified Landlords",
                                  value: "420",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Rejected",
                                  value: "7",
                                ),
                              ),
                            ],
                          );
                        },
                      ),

                      const SizedBox(height: 24),

                      const DataTableBox(
                        title: "",
                        columns: [
                          "Landlord",
                          "Email",
                          "Documents",
                          "Submitted",
                          "Decision",
                        ],
                        rows: [
                          [
                            "Omar Khalid",
                            "omar@example.com",
                            "ID + Ownership",
                            "Today",
                            "Accept / Reject",
                          ],
                          [
                            "Hanan Saleh",
                            "hanan@example.com",
                            "ID only",
                            "Yesterday",
                            "Accept / Reject",
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
