import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stats_card.dart';
import '../widgets/data_table_box.dart';

class ActivityLogsScreen extends StatefulWidget {
  const ActivityLogsScreen({super.key});

  @override
  State<ActivityLogsScreen> createState() => _ActivityLogsScreenState();
}

class _ActivityLogsScreenState extends State<ActivityLogsScreen> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 900;

    return Scaffold(
      drawer: isMobile
          ? Drawer(
        child: Sidebar(
          isCollapsed: false,
          onToggle: () {},
        ),
      )
          : null,
      body: Row(
        children: [
          if (!isMobile)
            Sidebar(
              isCollapsed: isCollapsed,
              onToggle: () {
                setState(() => isCollapsed = !isCollapsed);
              },
            ),
          Expanded(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Activity Logs",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 24),

                      LayoutBuilder(
                        builder: (context, constraints) {
                          final isNarrow = constraints.maxWidth < 900;
                          final double cardWidth = isNarrow
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 48) / 4;
                          return Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Today Actions",
                                  value: "34",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "This Week",
                                  value: "210",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Moderation",
                                  value: "98",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "System",
                                  value: "45",
                                ),
                              ),
                            ],
                          );
                        },
                      ),

                      const SizedBox(height: 24),

                      const DataTableBox(
                        title: "",
                        columns: [
                          "Timestamp",
                          "User",
                          "Action",
                          "Scope",
                          "Result",
                        ],
                        rows: [
                          [
                            "2025-11-03 10:20",
                            "Admin",
                            "Ban user",
                            "Users",
                            "Success",
                          ],
                          [
                            "2025-11-04 16:02",
                            "System",
                            "Backup",
                            "Infra",
                            "OK",
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
