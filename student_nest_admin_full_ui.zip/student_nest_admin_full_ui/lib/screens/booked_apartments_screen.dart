import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stats_card.dart';
import '../widgets/data_table_box.dart';

class BookedApartmentsScreen extends StatefulWidget {
  const BookedApartmentsScreen({super.key});

  @override
  State<BookedApartmentsScreen> createState() =>
      _BookedApartmentsScreenState();
}

class _BookedApartmentsScreenState extends State<BookedApartmentsScreen> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 900;

    return Scaffold(
      drawer: isMobile
          ? Drawer(
        child: Sidebar(
          isCollapsed: false,
          onToggle: () {},
        ),
      )
          : null,
      body: Row(
        children: [
          if (!isMobile)
            Sidebar(
              isCollapsed: isCollapsed,
              onToggle: () {
                setState(() => isCollapsed = !isCollapsed);
              },
            ),
          Expanded(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Booked Apartments",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 24),

                      LayoutBuilder(
                        builder: (context, constraints) {
                          final isNarrow = constraints.maxWidth < 900;
                          final double cardWidth = isNarrow
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 48) / 4;
                          return Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Bookings Today",
                                  value: "5",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Active Bookings",
                                  value: "210",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Cancellations",
                                  value: "4",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Pending Payments",
                                  value: "8",
                                ),
                              ),
                            ],
                          );
                        },
                      ),

                      const SizedBox(height: 24),

                      const DataTableBox(
                        title: "",
                        columns: [
                          "Student",
                          "Apartment",
                          "Landlord",
                          "Start",
                          "End",
                          "Status",
                          "Actions",
                        ],
                        rows: [
                          [
                            "sara@example.com",
                            "1BHK Near Uni",
                            "Omar Khalid",
                            "2025-11-01",
                            "2026-05-01",
                            "Confirmed",
                            "Cancel Booking",
                          ],
                          [
                            "reem@example.com",
                            "Shared Room",
                            "Hanan Saleh",
                            "2025-12-10",
                            "2026-06-10",
                            "Pending",
                            "Confirm",
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
