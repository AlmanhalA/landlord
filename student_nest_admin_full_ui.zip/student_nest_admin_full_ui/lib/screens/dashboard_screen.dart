import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stats_card.dart';
import '../widgets/search_field.dart';
import '../widgets/data_table_box.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 900;

    return Scaffold(
      drawer: isMobile
          ? Drawer(
              child: Sidebar(
                isCollapsed: false,
                onToggle: () {},
              ),
            )
          : null,
      body: Row(
        children: [
          if (!isMobile)
            Sidebar(
              isCollapsed: isCollapsed,
              onToggle: () {
                setState(() => isCollapsed = !isCollapsed);
              },
            ),
          Expanded(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Top row: title + date range
                      Row(
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Dashboard",
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "Overview of platform activity",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.color
                                          ?.withOpacity(0.7),
                                    ),
                              ),
                            ],
                          ),
                          const Spacer(),
                          OutlinedButton.icon(
                            onPressed: () {},
                            icon: const Icon(Icons.date_range, size: 18),
                            label: const Text("Last 30 days"),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      // Stats cards
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final isNarrow = constraints.maxWidth < 900;
                          return Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              SizedBox(
                                width: isNarrow
                                    ? constraints.maxWidth
                                    : (constraints.maxWidth - 48) / 4,
                                child: const StatsCard(
                                  title: "Total Users",
                                  value: "1,284",
                                  subtitle: "+8% vs last month",
                                  icon: Icons.people_alt_outlined,
                                ),
                              ),
                              SizedBox(
                                width: isNarrow
                                    ? constraints.maxWidth
                                    : (constraints.maxWidth - 48) / 4,
                                child: const StatsCard(
                                  title: "Verified Landlords",
                                  value: "312",
                                  subtitle: "92% verified",
                                  icon: Icons.verified_user_outlined,
                                ),
                              ),
                              SizedBox(
                                width: isNarrow
                                    ? constraints.maxWidth
                                    : (constraints.maxWidth - 48) / 4,
                                child: const StatsCard(
                                  title: "Active Listings",
                                  value: "842",
                                  subtitle: "+36 new today",
                                  icon: Icons.home_work_outlined,
                                ),
                              ),
                              SizedBox(
                                width: isNarrow
                                    ? constraints.maxWidth
                                    : (constraints.maxWidth - 48) / 4,
                                child: const StatsCard(
                                  title: "Open Reports",
                                  value: "19",
                                  subtitle: "5 high priority",
                                  icon: Icons.report_gmailerrorred_outlined,
                                  color: Colors.redAccent,
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 24),
                      // Search / filters
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: const SearchField(
                              hint: "Search activity, users or listings...",
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: DropdownButtonFormField<String>(
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: Theme.of(context).cardColor,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(999),
                                  borderSide: BorderSide.none,
                                ),
                              ),
                              value: "All types",
                              items: const [
                                DropdownMenuItem(
                                  value: "All types",
                                  child: Text("All activity types"),
                                ),
                                DropdownMenuItem(
                                  value: "Moderation",
                                  child: Text("Moderation"),
                                ),
                                DropdownMenuItem(
                                  value: "Bookings",
                                  child: Text("Bookings"),
                                ),
                                DropdownMenuItem(
                                  value: "Reports",
                                  child: Text("Reports"),
                                ),
                              ],
                              onChanged: (_) {},
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      DataTableBox(
                        title: "Recent Activity",
                        columns: const [
                          "Time",
                          "Action",
                          "User",
                          "Type",
                          "Status",
                        ],
                        rows: const [
                          [
                            "09:42",
                            "Approved listing #A-204",
                            "Admin • Khalifa",
                            "Listings",
                            "Success",
                          ],
                          [
                            "09:20",
                            "Rejected report #R-552",
                            "Moderator • Sara",
                            "Reports",
                            "Success",
                          ],
                          [
                            "08:55",
                            "New landlord submitted documents",
                            "Landlord • Omar",
                            "Verification",
                            "Pending",
                          ],
                          [
                            "08:10",
                            "Booking cancelled #B-991",
                            "Student • Lina",
                            "Booking",
                            "Refunded",
                          ],
                        ],
                        trailing: TextButton(
                          onPressed: () {},
                          child: const Text("View all"),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
