import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stats_card.dart';
import '../widgets/search_field.dart';
import '../widgets/data_table_box.dart';

class UsersManagementScreen extends StatefulWidget {
  const UsersManagementScreen({super.key});

  @override
  State<UsersManagementScreen> createState() => _UsersManagementScreenState();
}

class _UsersManagementScreenState extends State<UsersManagementScreen> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 900;

    return Scaffold(
      drawer: isMobile
          ? Drawer(
        child: Sidebar(
          isCollapsed: false,
          onToggle: () {},
        ),
      )
          : null,
      body: Row(
        children: [
          if (!isMobile)
            Sidebar(
              isCollapsed: isCollapsed,
              onToggle: () {
                setState(() => isCollapsed = !isCollapsed);
              },
            ),
          Expanded(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Users Management",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Top KPI cards (Active / Banned / Total)
                      LayoutBuilder(
                        builder: (context, constraints) {
                          final isNarrow = constraints.maxWidth < 900;
                          final double cardWidth = isNarrow
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 32) / 3;
                          return Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Active Users",
                                  value: "980",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Banned",
                                  value: "12",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Total",
                                  value: "1,234",
                                ),
                              ),
                            ],
                          );
                        },
                      ),

                      const SizedBox(height: 24),

                      // Search + Filter row
                      Row(
                        children: const [
                          Expanded(
                            flex: 2,
                            child: SearchField(
                              hint: "Search",
                            ),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: SearchField(
                              hint: "Filter",
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      // Main table
                      const DataTableBox(
                        title: "",
                        columns: [
                          "Name",
                          "Role",
                          "Email",
                          "Status",
                          "Actions",
                        ],
                        rows: [
                          [
                            "Sara Ali",
                            "Student",
                            "sara@example.com",
                            "Active",
                            "Deactivate / Ban",
                          ],
                          [
                            "Omar Khalid",
                            "Landlord",
                            "omar@example.com",
                            "Pending",
                            "Approve / Ban",
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
