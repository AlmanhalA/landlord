import 'package:flutter/material.dart';
import '../widgets/sidebar.dart';
import '../widgets/stats_card.dart';
import '../widgets/data_table_box.dart';

class ReportsViolationsScreen extends StatefulWidget {
  const ReportsViolationsScreen({super.key});

  @override
  State<ReportsViolationsScreen> createState() =>
      _ReportsViolationsScreenState();
}

class _ReportsViolationsScreenState extends State<ReportsViolationsScreen> {
  bool isCollapsed = false;

  @override
  Widget build(BuildContext context) {
    final bool isMobile = MediaQuery.of(context).size.width < 900;

    return Scaffold(
      drawer: isMobile
          ? Drawer(
        child: Sidebar(
          isCollapsed: false,
          onToggle: () {},
        ),
      )
          : null,
      body: Row(
        children: [
          if (!isMobile)
            Sidebar(
              isCollapsed: isCollapsed,
              onToggle: () {
                setState(() => isCollapsed = !isCollapsed);
              },
            ),
          Expanded(
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Reports & Violations",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 24),

                      LayoutBuilder(
                        builder: (context, constraints) {
                          final isNarrow = constraints.maxWidth < 900;
                          final double cardWidth = isNarrow
                              ? constraints.maxWidth
                              : (constraints.maxWidth - 48) / 4;
                          return Wrap(
                            spacing: 16,
                            runSpacing: 16,
                            children: [
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Open Reports",
                                  value: "12",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Resolved",
                                  value: "85",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Warnings",
                                  value: "23",
                                ),
                              ),
                              SizedBox(
                                width: cardWidth,
                                child: const StatsCard(
                                  title: "Suspensions",
                                  value: "6",
                                ),
                              ),
                            ],
                          );
                        },
                      ),

                      const SizedBox(height: 24),

                      const DataTableBox(
                        title: "",
                        columns: [
                          "Report ID",
                          "Reporter",
                          "Reported User",
                          "Issue",
                          "Status",
                          "Actions",
                        ],
                        rows: [
                          [
                            "R-1021",
                            "sara@example.com",
                            "omar@example.com",
                            "Misleading listing",
                            "Open",
                            "Warn / Suspend / Close",
                          ],
                          [
                            "R-1022",
                            "mohd@example.com",
                            "host@example.com",
                            "Spam",
                            "Resolved",
                            "Close",
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
